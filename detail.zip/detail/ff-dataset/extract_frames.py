# -*- coding: utf-8 -*-
import os, glob, cv2, random

BASE = os.path.join("original_sequences", "youtube", "c23", "videos")
OUT = "faces_500"
SIZE = (256, 256)
SEED = 42        # fixed seed for reproducibility
PER_VIDEO = 5    # 5 frames per video, 100 videos = 500 images

def extract_frames(video_path, out_dir, start_idx):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"  Cannot open: {video_path}")
        return start_idx

    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    if total <= 0:
        cap.release()
        return start_idx

    # pick PER_VIDEO unique random positions (seeded per video for reproducibility)
    n = min(PER_VIDEO, total)
    random.seed(SEED + start_idx)
    positions = sorted(random.sample(range(total), n))

    for t in positions:
        cap.set(cv2.CAP_PROP_POS_FRAMES, t)
        ok, frame = cap.read()
        if ok:
            resized = cv2.resize(frame, SIZE, interpolation=cv2.INTER_AREA)
            out_path = os.path.join(out_dir, f"{start_idx:03d}.jpg")
            cv2.imwrite(out_path, resized, [cv2.IMWRITE_JPEG_QUALITY, 95])
            start_idx += 1
    cap.release()
    return start_idx

def main():
    os.makedirs(OUT, exist_ok=True)
    videos = sorted(glob.glob(os.path.join(BASE, "*.mp4")))

    print(f"Found {len(videos)} videos, extracting frames...")
    print(f"Output dir: {OUT}/")
    print(f"Fixed seed: {SEED}, {PER_VIDEO} frames per video, target {len(videos)*PER_VIDEO} images")
    print(f"Target size: {SIZE[0]}x{SIZE[1]}\n")

    idx = 0
    for i, v in enumerate(videos, 1):
        name = os.path.basename(v)
        before = idx
        idx = extract_frames(v, OUT, idx)
        saved = idx - before
        print(f"  [{i:3d}/{len(videos)}] {name} -> {saved} frames")

    print(f"\nDone! Generated {idx} images in {OUT}/")

if __name__ == "__main__":
    main()
