# Efficient Deepfake Detection via Preprocessing and Cross-LLM Collaborative Reasoning

## Overview

A training-free deepfake detection framework combining lightweight image
preprocessing with multi-round collaborative reasoning between two LLMs
(Qwen + Moonshot).

## Folder Contents

This folder stores the per-image experiment logs of the project:

| Path | Content |
|---|---|
| `pre/` | Ablation logs on FFHQ/StyleGAN2 (1,000 images each): contrast / sharp / resolution applied alone |
| `ff/` | Cross-dataset results on FaceForensics++ (DeepFakes, c23), 500 images |
| `ff-dataset/` | Script to extract face frames from FF++ videos (for the real set) |
| `seed/` | Full pipeline repeated 3x on FFHQ/StyleGAN2 (seeds 42/43/44) |

**`ff/` naming** — `<true|fake>_<qwen|kimi>_<basic|group>_20260806_<details|summary>.csv`
- `true/fake`: FF++ real frames / DeepFakes frames (dataset label, not verdict)
- `basic`: single-model verdict; `group`: two-model collaborative reasoning
- `details`: per-image rows; `summary`: aggregated stats

**`seed/seed{42,43,44}/`** — one `results.csv` (per-image, per-round r1-r3
tokens/latency, `rounds_used`, per-model correctness) + one `summary.csv`
(overall accuracy, true/fake split, `r3_triggered_count`, latency) per run.

**CSV columns** — `ff/*_details.csv` and `pre/*.csv`: per-image
result/predicted_label, correctness, token usage and latency (`pre/` also has
`api_calls`).

## Experimental Setup

- Models: qwen-vl-plus-2025-08-15, moonshot-v1-32k-vision-preview
- Temperature: 0.1 | Seeds: 42/43/44 | Inference dates: 2026-8-6
- API failures/refusals: none encountered

## Datasets

- Real: FFHQ (500 images, random sampling without replacement)
- Fake: StyleGAN2 (500 images)
- Cross-dataset: FaceForensics++ (DeepFakes, c23) — results in `ff/`
- 3 repeated runs with different seeds (42/43/44) — results in `seed/`
- Raw FFHQ/StyleGAN2 images are not in this folder; only result CSVs.

## Reproducibility

The prompts shown in Fig. 2 of the paper are provided for reference,
illustrating the collaborative reasoning pipeline. The full experimental
prompts and source code are available upon request to the authors.
